class ScannerException(Exception):
    pass
class WrongHeaderException(Exception):
    pass
class SyntaxErrorException(Exception):
    pass
class OtherErrorException(Exception):
    pass